﻿using System;
using System.IO;
using System.Management;
using System.Windows.Forms;

namespace ATS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (DriveInfo driveInfo in DriveInfo.GetDrives())
            {
                if (driveInfo.DriveType == DriveType.Removable)
                {
                    comboBox1.Items.Add(driveInfo.Name.ToString());
                    comboBox1.ValueMember = driveInfo.Name.ToString();
                    comboBox1.DisplayMember = driveInfo.Name.ToString();
                }
            }

            //foreach (DriveInfo Drive in DriveInfo.GetDrives())
            //{
            //    if (Drive.DriveType == DriveType.Removable && Drive.IsReady)
            //    {
            //        USBSerialNumber usb = new USBSerialNumber();
            //        string serial = usb.getSerialNumberFromDriveLetter(Drive.ToString());
            //        if (serial == "4C530001191221114354")
            //        {
            //            if (File.Exists(Drive.ToString() + "BELLEK\\sabanci.ats"))
            //            {

            //            }
            //        }

            //    }
            //}
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != null && comboBox1.Text != "")
            {
                string Drive = comboBox1.Text.Substring(0, 2);
                USBSerialNumber usb = new USBSerialNumber();
                string serial = usb.getSerialNumberFromDriveLetter(Drive);
                
                MessageBox.Show(Drive + " diskinin serial numarası: " + serial, "Serial Number", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox1.Text = serial.ToString();

                foreach (ManagementObject item in new ManagementObjectSearcher("select * from Win32_DiskDrive").Get())
                {
                    textBox2.Text = item["PNPDeviceID"].ToString();
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
