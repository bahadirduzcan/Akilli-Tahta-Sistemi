﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Management;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace ATS_Setup
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Directory.Exists(comboBox1.SelectedItem + "\\ATS"))
                {
                    Directory.CreateDirectory(comboBox1.SelectedItem + "\\ATS");
                    Process p2 = new Process();
                    p2.StartInfo.FileName = "cmd";
                    p2.StartInfo.Arguments = "/c attrib +r +a +s +h " + comboBox1.SelectedItem + "\\ATS";
                    p2.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    p2.StartInfo.CreateNoWindow = true;
                    p2.StartInfo.RedirectStandardOutput = true;
                    p2.StartInfo.UseShellExecute = false;
                    p2.Start();
                }
                
                if (!File.Exists(comboBox1.SelectedItem + "\\ATS\\Bahax41_ATS_Creator4154.ATS"))
                {
                    File.Create(comboBox1.SelectedItem + "\\ATS\\Bahax41_ATS_Creator4154.ATS").Dispose();

                    using (StreamWriter writer = new StreamWriter(comboBox1.SelectedItem + "\\ATS\\Bahax41_ATS_Creator4154.ATS"))
                    {
                        writer.Write("5f4dcc3b5aa765d61d8327deb882cf99");
                    }

                    Process p = new Process();
                    p.StartInfo.FileName = "cmd";
                    p.StartInfo.Arguments = "/c attrib +r +a +s +h " + comboBox1.SelectedItem + "\\ATS\\Bahax41_ATS_Creator4154.ATS";
                    p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    p.StartInfo.CreateNoWindow = true;
                    p.StartInfo.RedirectStandardOutput = true;
                    p.StartInfo.UseShellExecute = false;
                    p.Start();
                }

                MessageBox.Show("Oluşturuldu.");
            }
            catch (Exception)
            {

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Flashlar();
        }

        void Flashlar()
        {
            comboBox1.Items.Clear();
            foreach (ManagementObject item in new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive WHERE InterfaceType LIKE 'USB%'").Get())
                foreach (ManagementObject partition in new ManagementObjectSearcher("ASSOCIATORS OF {Win32_DiskDrive.DeviceID='" + item.Properties["DeviceID"].Value + "'} WHERE AssocClass = Win32_DiskDriveToDiskPartition").Get())
                    foreach (ManagementObject disk in new ManagementObjectSearcher("ASSOCIATORS OF {Win32_DiskPartition.DeviceID='" + partition["DeviceID"] + "'} WHERE AssocClass = Win32_LogicalDiskToPartition").Get())
                        comboBox1.Items.Add(disk["Name"].ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Flashlar();
            MessageBox.Show("Yenilendi.");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!File.Exists("C:\\Windows\\System32\\Svchost\\svchost.exe"))
            {
                Directory.CreateDirectory("C:\\Windows\\System32\\Svchost");
                File.Copy("svchost.exe", "C:\\Windows\\System32\\Svchost\\svchost.exe");

                Process p = new Process();
                p.StartInfo.FileName = "cmd";
                p.StartInfo.Arguments = "/c attrib +r +a +s +h /s /d C:\\Windows\\System32\\Svchost";
                p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                p.StartInfo.CreateNoWindow = true;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.UseShellExecute = false;
                p.Start();

                Process p2 = new Process();
                p2.StartInfo.FileName = "cmd";
                p2.StartInfo.Arguments = "/c attrib +r +a +s +h C:\\Windows\\System32\\Svchost\\svchost.exe";
                p2.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                p2.StartInfo.CreateNoWindow = true;
                p2.StartInfo.RedirectStandardOutput = true;
                p2.StartInfo.UseShellExecute = false;
                p2.Start();

                MessageBox.Show("Oluşturuldu.");

                Process.Start("C:\\Windows\\System32\\Svchost\\svchost.exe");
            }
        }
    }
}
